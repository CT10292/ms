package com.citius.servicey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceyApplication.class, args);
	}

}
