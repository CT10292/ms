package com.citius.servicex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class GreetingController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@GetMapping("/greet")
	public String greet() {
		
		//String res = restTemplate.getForObject("http://localhost:8081/message", String.class);
		
		String res = restTemplate.getForEntity("http://localhost:8081/message", String.class).getBody();
				//return "Hello from Greeting Controller!! : " + res;
	
 		String out = restTemplate.postForObject("http://localhost:8081/message","some text",String.class);
			
		return "Hello from Greeting Controller!! : " + res + " :" + out;
	}
	}

